<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$shirts=Product::all();

       // return view('front.home',compact('shirts'));
	   return view('front.home');
    }
	
	public function shirts()
	{
		 //$shirts=Product::all();
        //return view('front.shirts',compact('shirts'));
	  return view('front.shirts');	
	}
	public function shirt()
	{
	  return view('front.shirt');	
	}
}
